# Dashboard Specification — BBD Regional Performance

## Data source

Connect Tableau Public to `data/orders_clean.csv`.

| Column | Classification |
|---|---|
| order_id | Dimension |
| order_month | Dimension |
| clean_first_name | Dimension |
| clean_last_name | Dimension |
| region | Dimension |
| rep_name | Dimension |
| item | Dimension |
| category | Dimension |
| unit_price | Measure |
| quantity | Measure |
| amount | Measure |
| revenue_calc | Measure |
| status | Dimension |

## KPI cards

- **Total Revenue:** `SUM(amount)` = **INR 346,200**. This equals Part A q05 `total_revenue` exactly.
- **Total Units Sold:** `SUM(quantity)` = **106 units**.

## Chart sheets

### Revenue by Region
- **Chart type:** horizontal bar chart.
- **Rows:** `region`; **Columns:** `SUM(amount)`; **Colour:** `region`.
- **Why:** bar lengths make regional revenue differences easy to compare.
- **Data table:**

| Region | Revenue (INR) |
|---|---:|
| East | 69500 |
| North | 119300 |
| South | 82500 |
| West | 74900 |

### Revenue by Category
- **Chart type:** horizontal bar chart.
- **Rows:** `category`; **Columns:** `SUM(amount)`; **Colour:** `category`.
- **Why:** bars compare the contribution of the three product categories without implying a time sequence.

| Category | Revenue (INR) |
|---|---:|
| Apparel | 77500 |
| Electronics | 142300 |
| Home | 126400 |

### Revenue Trend by Month and Category
- **Chart type:** line chart.
- **Columns:** `order_month` (discrete text in chronological order); **Rows:** `SUM(amount)`; **Colour:** `category`; one line per category.
- **Why:** a line chart reveals month-to-month movement for each category.

| Order month | Apparel | Electronics | Home | Total |
|---|---:|---:|---:|---:|
| 2026-09 | 24700 | 43000 | 30600 | 98300 |
| 2026-10 | 30600 | 49900 | 12600 | 93100 |
| 2026-11 | 22200 | 49400 | 83200 | 154800 |

### Region x Category Detail
- **Chart type:** text table / crosstab.
- **Rows:** `region`; **Columns:** `category`; **Colour:** `SUM(amount)` using a restrained sequential intensity (optional).
- **Why:** exact values support audit and drill-down rather than relying on visual estimates.

| Region | Apparel | Electronics | Home | Total |
|---|---:|---:|---:|---:|
| East | 10600 | 21400 | 37500 | 69500 |
| North | 19400 | 73400 | 26500 | 119300 |
| South | 10000 | 28700 | 43800 | 82500 |
| West | 37500 | 18800 | 18600 | 74900 |
| **Grand Total** | 77500 | 142300 | 126400 | 346200 |

## Dashboard layout

1. **Top band:** horizontal container with two KPI cards (Total Revenue, Total Units Sold).
2. **Directly below KPI cards:** category filter in its own horizontal/top-band row. Apply it to all four worksheets using this data source.
3. **Trend chart:** full-width line chart beneath the filter.
4. **Comparison charts:** horizontal container with Revenue by Region and Revenue by Category side by side.
5. **Detail table:** full-width Region x Category Detail at the bottom.

Use a vertical container as the overall dashboard scaffold, horizontal containers for the KPI cards and the two comparison charts, and a separate horizontal filter band. With **Use as Filter** enabled on Revenue by Region, clicking a region bar filters the trend, category comparison and detail table to that selected region (subject to the category filter).

## Visualization summary

The dashboard reconciles completed-order revenue across regional, category, monthly and region-category views. It also reports units sold and allows the category filter to update every worksheet.

## Summary analysis

1. **Regional comparison:** North generated INR {rev_region['North']:,}, compared with South at INR {rev_region['South']:,}; North is higher by INR {rev_region['North']-rev_region['South']:,}.
2. **Category contribution:** Home generated INR {rev_cat['Home']:,}, while Apparel generated INR {rev_cat['Apparel']:,}; the category table identifies where revenue is concentrated.
3. **Monthly movement:** September revenue was INR {sum(pivot2['2026-09']) if False else sum(d['amount'] for d in enriched if d['order_month']=='2026-09'):,}, October was INR {sum(d['amount'] for d in enriched if d['order_month']=='2026-10'):,}, and November was INR {sum(d['amount'] for d in enriched if d['order_month']=='2026-11'):,}; this is a rise/fall pattern to investigate by category rather than assuming a cause.
4. **Units:** {units} units were sold across {len(enriched)} completed orders, an average of {units/len(enriched):.2f} units per completed order.

## Recommendations

1. **North + Home:** run a measured, limited Home-category promotion in North, where the region-category table shows INR {region_cat[('North','Home')]:,}. Compare incremental Home revenue and units in North against a comparable non-promotion period before expanding spend.
2. **South + Electronics:** test a targeted Electronics offer in South, which contributed INR {region_cat[('South','Electronics')]:,} in the region-category table. Track South Electronics revenue, units sold and average order value during the test.
3. **Apparel inventory:** use the monthly category trend to stage Apparel inventory and promotion timing; Apparel generated INR {rev_cat['Apparel']:,} overall. Track monthly Apparel revenue and completed-order count to determine whether the inventory/promotion adjustment improves results.

## Reconciliation

| Check | Value (INR) |
|---|---:|
| Total Revenue KPI | {sum(d['amount'] for d in enriched)} |
| Sum of Revenue by Region | {sum(rev_region.values())} |
| Sum of Revenue by Category | {sum(rev_cat.values())} |
| Part B pivot grand total | {sum(d['amount'] for d in enriched)} |
