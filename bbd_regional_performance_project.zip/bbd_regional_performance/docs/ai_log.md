# AI Assistance and Verification Log

## 1. Five-part prompt for q13

**Role:** You are a careful SQL business analyst writing auditable reporting queries.

**Task:** Write the q13 query that reports each sales representative's completed-order revenue by order month and classifies performance against the representative's monthly target.

**Context:** Use the real tables and columns: `reps(rep_id, rep_name, region, monthly_target)`, `customers(customer_id, first_name, last_name, city, region, age, rep_id)`, and `orders(order_id, customer_id, item, quantity, amount, status, order_month)`. SQL dialect used for this project: SQLite.

**Constraints:** Count completed orders only (`orders.status = 'completed'`). Join reps to customers using `rep_id`, and customers to orders using `customer_id`. Group by representative, order month and `monthly_target`. Set `performance_tier` to Below Target when revenue is below target, On Target when revenue is at least target but below 1.1 times target, and Above Target otherwise. Do not use `WITH` clauses or stored procedures. Do not filter on aggregate aliases in `WHERE` or `GROUP BY`; write the aggregate expression directly inside the `CASE`.

**Format:** Return raw SQL only, with inline comments.

## 2. Scenario D1 — defects in the assistant's answer

| Defect | Classification | Why it is defective | Correct fix |
|---|---|---|---|
| `sales` table does not exist in the supplied schema | fake method/function | The real schema has `orders`, not `sales` | Query `orders` joined to `customers` |
| `region_name` and `total_sales` columns do not exist | fake method/function | Real region is `customers.region`; monetary value is `orders.amount` | Use `c.region` and `o.amount` |
| `SUM(total_sales) > 80000` is in `WHERE` | logic error | SQL filters groups with `HAVING`, not `WHERE`; aggregates cannot be used in `WHERE` | Put `HAVING SUM(o.amount) > 80000` after `GROUP BY` |
| “revenue grew 38% month over month” | phantom statistic | The claim is not supported by the query or data and conflicts with q11 | Calculate the change from completed revenue for the relevant months |

## 3. Scenario D1 — corrected query and execution

Saved in `sql/d1_corrected.sql` and executed against the seeded SQLite database.

| Region | Revenue (INR) |
|---|---:|
| North | 119300 |
| South | 82500 |

North revenue in 2026-09 was INR 53,500; North revenue in 2026-10 was INR 41,300. Month-over-month change = `((October - September) / September) × 100` = **-22.8%**. This is a decline, so the assistant's 38% growth claim is contradicted by the data.

## 4. Human-in-the-loop protocol

- **Specification:** I translated “which regions sell the most?” into a precise question: sum `orders.amount` for completed orders, grouped by the customer's region, retaining regions above INR 80,000.
- **Execution:** I ran the corrected SQL against the provided seed in SQLite and recorded the two returned rows, North (INR 119,300) and South (INR 82,500).
- **Inspection:** I checked table and column names against the schema, verified that `status = 'completed'` is applied before grouping, and confirmed the threshold is in `HAVING`.
- **Verification:** I compared the query results with the supplied data and used q11's North month totals to calculate the actual September-to-October change of -22.8%, not +38%.
- **Decision:** **Reject** the original answer because it references nonexistent schema objects, places an aggregate in `WHERE`, and asserts an unsupported statistic contradicted by q11. **Accept** the corrected query because it executes on the real schema and returns North (INR 119,300) and South (INR 82,500), matching the expected results.

## 5. Scenario D2 — five-part diagnostic prompt

**Role:** Act as a spreadsheet formula-debugging analyst.

**Task:** Diagnose why a lookup returns a not-found error and provide the smallest reliable repair.

**Context:** The actual formula is `=VLOOKUP(G2, $A$2:$C$10, 3, FALSE)`. Cell `G2` on the `orders` tab contains ` Smart Watch` with one leading space. The `products` tab occupies `A1:C10`; item names are in column A and unit prices are in column C. `Smart Watch` exists in the products list without a leading space.

**Constraints:** Preserve exact-match behaviour, use the existing table layout, and do not change the source product name just to make the lookup work. Explain the root cause and show a repaired formula.

**Format:** Give a short diagnosis followed by the corrected spreadsheet formula.

**Root cause:** The lookup key has a leading space, so the exact-match VLOOKUP compares ` Smart Watch` with `Smart Watch` and does not find a match.

**Repaired formula:** `=VLOOKUP(TRIM(G2), products!$A$2:$C$10, 3, FALSE)`

## 6. Skeptical-analyst check on Part C

**Prompt:** “Act as a skeptical business analyst. Challenge my first recommendation to run a measured Home-category promotion in North. Identify unstated assumptions, distinguish correlation from evidence of cause, ask what additional comparison or experiment is needed, and state what data would weaken or strengthen the recommendation. Do not simply agree with the recommendation.”

| Unstated assumption | Figure or check that would confirm or weaken it |
|---|---|
| North Home revenue has room to grow and is not already near its natural ceiling | Check North Home revenue of INR 26,500 against Home revenue in other regions and compare unit counts; low revenue alone does not prove opportunity |
| A promotion would cause incremental sales rather than discounting purchases that would happen anyway | Run a controlled or matched-period test and compare incremental revenue and units against a non-promoted baseline; the current dataset has no promotion flag or discount field |
| Stock and fulfilment can support extra demand profitably | Check available inventory, margin and fulfilment capacity before launch; these fields are absent from this dataset, so the recommendation remains a test hypothesis rather than a proven causal conclusion |
