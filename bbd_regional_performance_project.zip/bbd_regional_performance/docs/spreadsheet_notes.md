# Spreadsheet Notes

## Formulas (first data row, row 2)

Assuming `orders` columns A:J are the q09 fields in their exported order, with raw names in C:D, item in G, quantity in H and amount in I; appended columns start at K.

- `clean_first_name` (K2): `=PROPER(TRIM(C2))`
- `clean_last_name` (L2): `=PROPER(TRIM(D2))`
- `category` (M2): `=VLOOKUP(G2,products!$A$2:$C$10,2,FALSE)`
- `unit_price` (N2): `=XLOOKUP(G2,products!$A$2:$A$10,products!$C$2:$C$10,"UNKNOWN_ITEM")`
- `revenue_calc` (O2): `=N2*H2`

Fill each formula down through row 91. In a spare cell, test `=XLOOKUP("Mystery Item",products!$A$2:$A$10,products!$C$2:$C$10,"UNKNOWN_ITEM")`; expected result: `UNKNOWN_ITEM`.

## Completed-order aggregates

| Metric | Formula | Result |
|---|---|---:|
| COUNT | `=COUNT(amount_range)` | 63 |
| SUM | `=SUM(amount_range)` | 346200 |
| AVERAGE | `=AVERAGE(amount_range)` | 5495.24 |
| MIN | `=MIN(amount_range)` | 1100 |
| MAX | `=MAX(amount_range)` | 15600 |

Use the actual `amount` column range on `completed_orders` for `amount_range`.

## Pivot table (i): sum of amount by category and region

| Category | East | North | South | West | Grand Total |
|---|---:|---:|---:|---:|---:|
| Apparel | 10600 | 19400 | 10000 | 37500 | 77500 |
| Electronics | 21400 | 73400 | 28700 | 18800 | 142300 |
| Home | 37500 | 26500 | 43800 | 18600 | 126400 |
| **Grand Total** | 69500 | 119300 | 82500 | 74900 | 346200 |

## Pivot table (ii): amount and order count by month

| Order month | Sum of amount | Count of order_id |
|---|---:|---:|
| 2026-09 | 98300 | 19 |
| 2026-10 | 93100 | 20 |
| 2026-11 | 154800 | 24 |
| **Grand Total** | 346200 | 63 |

## Reconciliation

| Metric | Spreadsheet | Part A q05 | Match/Mismatch |
|---|---:|---:|---|
| COUNT | 63 | 63 | Match |
| SUM | 346200 | 346200 | Match |
| AVERAGE | 5495.24 | 5495.24 | Match |

## Data validation

- **Missing amounts:** q02 identifies order IDs 1001, 1010 and 1064; all are pending. They are excluded from completed-order revenue and the completed-order spreadsheet by the status filter. Do not replace missing amounts with zero: that would fabricate a value and could distort averages.
- **Data types:** order IDs and quantity are whole numbers; unit_price, amount and revenue_calc are numeric values, not text. `order_month` is kept as plain text (`YYYY-MM`) so it is not converted to a date serial.
- **Duplicates and outliers:** no duplicate `order_id` values were found in the 63 completed orders. Largest completed amount is INR 15600; order IDs with that amount: 1061, 1065, 1069, 1077. This is a high-value order relative to many rows but is consistent with three units of Air Fryer at INR 5,200 each; flag for business review rather than delete as an error.
- **Handover decision:** keep raw names alongside cleaned names on the `orders` tab so transformations are auditable; use only cleaned names downstream and never overwrite source values.

## Setup

- Tabs: `orders` and `products`; the filtered, value-only result is `completed_orders`.
- Imported rows in `orders`: 90 data rows (plus header).
- `products` range: `A1:C10` including header.
- Filter applied: `status = completed`; visible rows sorted by `amount` largest to smallest before pasting values into `completed_orders`.
- Missing-key lookup test: `Mystery Item` returns `UNKNOWN_ITEM`.
- Note: formulas shown above use the stated `orders` layout; if the spreadsheet import places columns differently, adjust cell references while preserving the same logic.
