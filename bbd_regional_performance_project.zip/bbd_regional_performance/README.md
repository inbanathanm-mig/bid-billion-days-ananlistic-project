# Big Billion Days Regional Performance Review

## Project title
Big Billion Days Regional Performance Review — SQL, Spreadsheet, Dashboard and AI-Verified Analysis

## Tools and assumptions
- **SQL compiler / dialect:** SQLite, run locally through Python's built-in SQLite engine for reproducible execution. The SQL is compatible with SQLite.
- **Spreadsheet tool:** Google Sheets (formula documentation and expected outputs are provided in `docs/spreadsheet_notes.md`; CSV exports are generated from the same seed).
- **Dashboard:** Not built in Tableau Public; Part C is delivered as a precise rebuild specification and verified data tables.
- **Assumptions:** Revenue includes only rows where status is `completed`. Missing amounts are left blank and not imputed. `order_month` remains text. In spreadsheet formulas, the columns are assumed to be imported in q09 order before the added columns.

## Three most important findings
North is the leading region by completed-order revenue in the dataset, but its revenue falls from INR 53,500 in September to INR 41,300 in October (-22.8% month over month), contradicting the unsupported 38% growth claim. Completed orders generate INR 346,200 across 63 orders and 106 units, which reconciles across the SQL KPI, cleaned CSV and dashboard specification. Category and region-category tables identify Home in North and Electronics in South as testable promotional opportunities, but the available data does not establish that a promotion would cause incremental sales.

## File index
| File | Part / purpose |
|---|---|
| `sql/00_schema_and_seed.sql` | Part A — schema and seed data |
| `sql/q01.sql` | Part A — reporting query q01 |
| `sql/q02.sql` | Part A — reporting query q02 |
| `sql/q03.sql` | Part A — reporting query q03 |
| `sql/q04.sql` | Part A — reporting query q04 |
| `sql/q05.sql` | Part A — reporting query q05 |
| `sql/q06.sql` | Part A — reporting query q06 |
| `sql/q07.sql` | Part A — reporting query q07 |
| `sql/q08.sql` | Part A — reporting query q08 |
| `sql/q09.sql` | Part A — reporting query q09 |
| `sql/q10.sql` | Part A — reporting query q10 |
| `sql/q11.sql` | Part A — reporting query q11 |
| `sql/q12.sql` | Part A — reporting query q12 |
| `sql/q13.sql` | Part A — reporting query q13 |
| `sql/d1_corrected.sql` | Part D — corrected regional revenue query |
| `results/query_results.md` | Part A — row counts and query outputs |
| `data/orders_enriched.csv` | Part A — q09 full order-level output |
| `data/orders_clean.csv` | Part B — completed, cleaned, enriched export |
| `docs/spreadsheet_notes.md` | Part B — formulas, pivots, validation and reconciliation |
| `docs/dashboard_spec.md` | Part C — dashboard specification and narrative |
| `docs/ai_log.md` | Part D — prompts, defect review and human verification |
